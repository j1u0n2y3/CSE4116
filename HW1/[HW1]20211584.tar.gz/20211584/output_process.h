#ifndef _OUTPUT_P_H_
#define _OUTPUT_P_H_

#include "main.h"
#include "device.h"

void output_process();
void output_reset();

#endif /* _OUTPUT_P_H_ */